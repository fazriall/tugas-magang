@extends('layouts.frontend')

@section('content')
<div class="container">
    <h1>Penginapan di Kota Padang</h1>
    <p>Berikut adalah daftar penginapan yang tersedia:</p>
    <!-- Tambahkan konten atau daftar penginapan di sini -->
</div>
@endsection
