@extends('layouts.app')

@section('content')
    <h1>jbnfdvkijsa</h1>
@endsection
